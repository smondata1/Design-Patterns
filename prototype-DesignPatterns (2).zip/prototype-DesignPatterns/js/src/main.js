import {Stock} from './stock.js';

Handlebars.registerPartial('stock-history', Handlebars.templates['stock-history']);

const stockTemplate = Handlebars.templates['stock-current'];


(() => {
  const displayStock = (wobj, el) => {
    wobj.getStockPriceAndHistory().then(() => {
        el.innerHTML = stockTemplate(wobj.stockData);
    });
}

document
.querySelector('.frm.symbol')
.addEventListener('submit', function (e) {
    let location = e
        .target
        .querySelector('[name=symbol]')
        .value;
    
    displayStock(new Stock({stock: symbol}), document.querySelector('.stock-display'));

    e.preventDefault();
});

})();