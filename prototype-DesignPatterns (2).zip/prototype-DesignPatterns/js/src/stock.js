
var API_KEY = 'L4LJWNH4YMFNUWUH';
var ENDPOINT = 'https://www.alphavantage.co/query?function=';

const Stock = function (opts){
    this.symbol = '';
    this.stockData = {}
    if (opts) {
        Object.assign(this, opts);
    }




Stock.prototype.getStock = function () {
return fetch(`${ENDPOINT}GLOBAL_QUOTE&symbol=${this.symbol}&apikey=${API_KEY}`)
  .then (response => {
    return response.json();
  })
  .then(data => {
    let {'01. symbol': symbol, '05. price': price, '07. latest trading day': date} = data['Global Quote'];

     console.log(symbol);
     console.log(price);
     console.log(date);
      return Object.assign(this.stockData, {symbol, price, date});
  });
};

Stock.prototype.getHistory = function () {
    return fetch(`${ENDPOINT}TIME_SERIES_DAILY&symbol=${this.symbol}&apikey=${API_KEY}`)
    .then(function (response) {
        return response.json();
      }).then(data => {
        let fiveDays = data.map(day => {
          let {'1. open': open, '2. high': high, '3. low': low, '4. close': close} = day[1];
  
          return {open, high, low, close, date: day[0]};
          
      });
      console.log(fiveDays);
        return Object.assign(this.stockData, {fiveDays});

    })
}



Stock.prototype.getStockPriceAndHistory = function () {
    return this.getStock(this.symbol)
    .then(() => {
        return this.getHistory(this.symbol);
    })
    .then(() => {
        return this.stockData;
    })
  }

  

}
window.Stock = Stock;

export {Stock};